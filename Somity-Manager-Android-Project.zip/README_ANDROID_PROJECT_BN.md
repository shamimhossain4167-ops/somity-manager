# Somity Manager - Android Project

এই ZIP-এ APK তৈরির জন্য প্রয়োজনীয় Android project-এর মূল ফাইলগুলো রাখা হয়েছে।

Included:
- build.gradle.kts
- settings.gradle.kts
- gradle.properties
- app/build.gradle.kts
- app/src/main/AndroidManifest.xml
- app/src/main/java/.../MainActivity.java
- app/src/main/res/values/styles.xml

নোট:
এই project-এ Gradle Wrapper (gradlew, gradlew.bat, gradle/wrapper) মূল ZIP-এ ছিল না। AndroidIDE/Android Studio-তে project খুলে IDE-এর Gradle ব্যবহার করে sync/build করতে হবে।
