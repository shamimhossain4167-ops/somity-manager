/**
 * Code.gs
 * Google Sheet backend for the সমিতি Admin & Viewer app.
 *
 * Setup:
 * 1. Add this file as Code.gs and the supplied HTML as index.html.
 * 2. Deploy as Web app -> Execute as Me.
 * 3. If SHEET_ID is left as the placeholder, the first run will create a
 *    Google Sheet automatically and remember its ID in Script Properties.
 * 4. If you already have a Google Sheet, put its ID into SHEET_ID instead.
 */

const SHEET_ID = 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE';
const DEFAULT_ADMIN_PIN = '1234'; // চাইলে Settings থেকে পরিবর্তন করুন

const HEADERS = {
  Members: ['id','name','mobile','address','join','investment','paid','due','email','whatsapp','notes','photoUrl'],
  Transactions: ['id','memberId','date','month','amount','due','note'],
  Cars: ['id','name','owner','title','schedule','total','paid','balance','invest','expense'],
  CarEntries: ['carId','ref','month','scheduled','paid','date','note'],
  Committee: ['role','name','mobile','address'],
  Settings: ['key','value'],
  BusinessInvestments: ['id','date','name','amount','note'],
  Expenses: ['id','date','name','amount','note']
};

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('সমিতি Admin & Viewer')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function ss_() {
  let id = SHEET_ID;
  if (id === 'PASTE_YOUR_GOOGLE_SHEET_ID_HERE') {
    id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
    if (!id) {
      const ss = SpreadsheetApp.create('শিংলাব-চরপোটান সমবায় সমিতি লিঃ — Online হিসাব');
      id = ss.getId();
      PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', id);
      return ss;
    }
  }
  return SpreadsheetApp.openById(id);
}

function ensureSheets_() {
  const ss=ss_();
  Object.keys(HEADERS).forEach(n=>{
    let sh=ss.getSheetByName(n);
    if(!sh)sh=ss.insertSheet(n);
    sh.getRange(1,1,1,HEADERS[n].length).setValues([HEADERS[n]]);
    sh.setFrozenRows(1);
  });
}

function num_(v){const n=Number(v);return isNaN(n)?0:n;}

function rows_(name){
  const sh=ss_().getSheetByName(name);
  if(!sh||sh.getLastRow()<2)return [];
  const v=sh.getDataRange().getValues(), h=v[0].map(String);
  return v.slice(1).filter(r=>r.some(x=>x!=='')).map(r=>{
    const o={};h.forEach((k,i)=>o[k]=r[i]);return o;
  });
}

function getAdminPin_(){
  const x=rows_('Settings').find(r=>String(r.key)==='adminPin');
  return x?String(x.value):DEFAULT_ADMIN_PIN;
}

function checkPin(pin){return String(pin||'')===getAdminPin_();}

/**
 * Change only the Admin PIN.
 * This function intentionally updates only the adminPin row in Settings,
 * so members, transactions, cars, committee and other data are untouched.
 */
function changeAdminPin(currentPin, newPin){
  const current=String(currentPin||'').trim();
  const next=String(newPin||'').trim();

  if(!current) throw new Error('বর্তমান Admin PIN দিন।');
  if(!next) throw new Error('নতুন Admin PIN দিন।');
  if(next.length < 4) throw new Error('নতুন Admin PIN কমপক্ষে ৪ সংখ্যার হতে হবে।');
  if(!/^\d+$/.test(next)) throw new Error('Admin PIN শুধু সংখ্যা দিয়ে দিন।');
  if(current !== getAdminPin_()) throw new Error('বর্তমান Admin PIN সঠিক নয়।');

  const sh=ss_().getSheetByName('Settings');
  if(!sh) throw new Error('Settings Sheet পাওয়া যায়নি।');

  const last=sh.getLastRow();
  if(last < 1) throw new Error('Settings Sheet খালি।');

  const values=sh.getRange(1,1,last,2).getValues();
  let found=false;
  for(let r=1;r<values.length;r++){
    if(String(values[r][0]) === 'adminPin'){
      sh.getRange(r+1,2).setValue(next);
      found=true;
      break;
    }
  }

  if(!found){
    sh.getRange(last+1,1,1,2).setValues([['adminPin',next]]);
  }

  return {success:true};
}

function getDB(){
  ensureSheets_();

  const members=rows_('Members').map(x=>({
    id:String(x.id||''),name:String(x.name||''),mobile:String(x.mobile||''),
    address:String(x.address||''),join:String(x.join||''),
    investment:num_(x.investment),paid:num_(x.paid),due:num_(x.due),
    email:String(x.email||''),whatsapp:String(x.whatsapp||''),notes:String(x.notes||''),photoUrl:String(x.photoUrl||'')
  }));

  const txns=rows_('Transactions').map(x=>({
    id:String(x.id||''),memberId:String(x.memberId||''),date:String(x.date||''),
    month:String(x.month||''),amount:num_(x.amount),due:num_(x.due),note:String(x.note||'')
  }));

  const cars=rows_('Cars').map(x=>({
    id:String(x.id||''),name:String(x.name||''),owner:String(x.owner||''),
    title:String(x.title||''),schedule:String(x.schedule||''),
    total:num_(x.total),paid:num_(x.paid),balance:num_(x.balance),
    invest:num_(x.invest),expense:num_(x.expense),entries:[]
  }));

  const ce=rows_('CarEntries');
  cars.forEach(c=>c.entries=ce.filter(e=>String(e.carId)===String(c.id)).map(e=>({
    ref:String(e.ref||''),month:String(e.month||''),scheduled:num_(e.scheduled),
    paid:num_(e.paid),date:String(e.date||''),note:String(e.note||'')
  })));

  const committee=rows_('Committee').map(x=>({
    role:String(x.role||''),name:String(x.name||''),mobile:String(x.mobile||''),address:String(x.address||'')
  }));

  const settings={association:'শিংলাব-চরপোটান সমবায় সমিতি লিঃ',subtitle:'অনলাইন হিসাব ও সদস্য ব্যবস্থাপনা'};
  const businessInvestments=rows_('BusinessInvestments').map(x=>({id:String(x.id||''),date:String(x.date||''),name:String(x.name||''),amount:num_(x.amount),note:String(x.note||'')}));
  const expenses=rows_('Expenses').map(x=>({id:String(x.id||''),date:String(x.date||''),name:String(x.name||''),amount:num_(x.amount),note:String(x.note||'')}));
  let openingCash=0;
  rows_('Settings').forEach(x=>{
    if(String(x.key)==='association')settings.association=String(x.value||'');
    if(String(x.key)==='subtitle')settings.subtitle=String(x.value||'');
    if(String(x.key)==='openingCash')openingCash=num_(x.value);
  });

  return {members,txns,cars,committee,settings,openingCash,adminPin:'',businessInvestments,expenses};
}

function write_(name,rows){
  const sh=ss_().getSheetByName(name);
  sh.clearContents();
  sh.getRange(1,1,1,HEADERS[name].length).setValues([HEADERS[name]]);
  if(rows.length)sh.getRange(2,1,rows.length,HEADERS[name].length).setValues(rows);
}

function saveDB(db){
  ensureSheets_();

  write_('Members',(db.members||[]).map(m=>[
    m.id||'',m.name||'',m.mobile||'',m.address||'',m.join||'',
    num_(m.investment),num_(m.paid),num_(m.due),m.email||'',m.whatsapp||'',m.notes||'',m.photoUrl||''
  ]));

  write_('Transactions',(db.txns||[]).map(t=>[
    t.id||'',t.memberId||'',t.date||'',t.month||'',num_(t.amount),num_(t.due),t.note||''
  ]));

  write_('Cars',(db.cars||[]).map(c=>[
    c.id||'',c.name||'',c.owner||'',c.title||'',c.schedule||'',
    num_(c.total),num_(c.paid),num_(c.balance),num_(c.invest),num_(c.expense)
  ]));

  const entries=[];
  (db.cars||[]).forEach(c=>(c.entries||[]).forEach(e=>entries.push([
    c.id||'',e.ref||'',e.month||'',num_(e.scheduled),num_(e.paid),e.date||'',e.note||''
  ])));
  write_('CarEntries',entries);

  write_('Committee',(db.committee||[]).map(c=>[
    c.role||'',c.name||'',c.mobile||'',c.address||''
  ]));

  write_('BusinessInvestments',(db.businessInvestments||[]).map(x=>[x.id||'',x.date||'',x.name||'',num_(x.amount),x.note||'']));
  write_('Expenses',(db.expenses||[]).map(x=>[x.id||'',x.date||'',x.name||'',num_(x.amount),x.note||'']));

  write_('Settings',[
    ['association',db.settings?.association||'শিংলাব-চরপোটান সমবায় সমিতি লিঃ'],
    ['subtitle',db.settings?.subtitle||'অনলাইন হিসাব ও সদস্য ব্যবস্থাপনা'],
    ['openingCash',num_(db.openingCash)],
    ['adminPin',db.adminPin?String(db.adminPin):getAdminPin_()]
  ]);

  return {success:true};
}

function uploadMemberPhoto(memberId, dataUrl){
  const match=String(dataUrl||'').match(/^data:(image\/[^;]+);base64,(.+)$/);
  if(!match) throw new Error('ছবির ফাইল সঠিক নয়।');
  const folderName='Shinglab Somiti Member Photos';
  const it=DriveApp.getFoldersByName(folderName);
  const folder=it.hasNext()?it.next():DriveApp.createFolder(folderName);
  const ext=(match[1].split('/')[1]||'jpg').replace('jpeg','jpg');
  const blob=Utilities.newBlob(Utilities.base64Decode(match[2]),match[1],'member_'+memberId+'.'+ext);
  const file=folder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK,DriveApp.Permission.VIEW);
  const sh=ss_().getSheetByName('Members');
  const data=sh.getDataRange().getValues();
  for(let r=1;r<data.length;r++){if(String(data[r][0])===String(memberId)){sh.getRange(r+1,12).setValue(file.getUrl());return file.getUrl();}}
  throw new Error('সদস্য পাওয়া যায়নি।');
}


// ===== Google Drive Backup =====
function getOrCreateBackupFolder_(){
  const folderName='Shinglab Somiti Backups';
  const it=DriveApp.getFoldersByName(folderName);
  return it.hasNext()?it.next():DriveApp.createFolder(folderName);
}

function createManualBackup(){
  return createBackup_('Manual Backup');
}

function createDailyBackup(){
  createBackup_('Daily Backup');
}

function createBackup_(label){
  const file=DriveApp.getFileById(ss_().getId());
  const folder=getOrCreateBackupFolder_();
  const tz=Session.getScriptTimeZone()||'Asia/Dhaka';
  const stamp=Utilities.formatDate(new Date(),tz,'yyyy-MM-dd_HH-mm-ss');
  const copy=file.makeCopy('Shinglab_Somiti_'+label.replace(/\s+/g,'_')+'_'+stamp,folder);
  return {name:copy.getName(),url:copy.getUrl(),id:copy.getId()};
}

function setupDailyBackup(){
  // Remove old copies of this trigger so multiple daily backups are not created.
  ScriptApp.getProjectTriggers().forEach(t=>{
    if(t.getHandlerFunction()==='createDailyBackup') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('createDailyBackup').timeBased().everyDays(1).atHour(2).create();
  return {success:true};
}

function makeReportPdf(){
  const db=getDB();
  const doc=DocumentApp.create((db.settings.association||'সমিতি')+' - পূর্ণ হিসাব');
  const body=doc.getBody();
  body.appendParagraph(db.settings.association||'সমিতি').setHeading(DocumentApp.ParagraphHeading.TITLE);
  body.appendParagraph(db.settings.subtitle||'').setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph('প্রস্তুতের তারিখ: '+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'dd/MM/yyyy HH:mm'));
  const memberPaid=db.members.reduce((a,m)=>a+num_(m.paid),0);
  const carPaid=db.cars.reduce((a,c)=>a+c.entries.reduce((z,e)=>z+num_(e.paid),0),0);
  const carInvest=db.cars.reduce((a,c)=>a+num_(c.invest),0);
  const bizInvest=db.businessInvestments.reduce((a,x)=>a+num_(x.amount),0);
  const carExpense=db.cars.reduce((a,c)=>a+num_(c.expense),0);
  const otherExpense=db.expenses.reduce((a,x)=>a+num_(x.amount),0);
  const hand=num_(db.openingCash)+memberPaid+carPaid-carInvest-bizInvest-carExpense-otherExpense;
  body.appendParagraph('সার্বিক ওভারভিউ').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendTable([['বিষয়','টাকা'],['মোট কিস্তি উত্তোলন',String(memberPaid)],['গাড়ির কিস্তি উত্তোলন',String(carPaid)],['ব্যবসায় বিনিয়োগ',String(bizInvest)],['গাড়ির ইনভেস্টমেন্ট',String(carInvest)],['অন্যান্য খরচ',String(otherExpense+carExpense)],['হাতে থাকা টাকা',String(hand)]]);
  body.appendParagraph('সদস্য তালিকা').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendTable([['ID','নাম','মোবাইল','জমা','কিস্তি','বকেয়া'],...db.members.map(m=>{const total=scheduledInstallments_(),paid=num_(m.paid),count=Math.floor(paid/2000),due=Math.max(total*2000-paid,0);return [m.id,m.name,m.mobile,String(paid),count+'/'+total,String(due)]})]);
  body.appendParagraph('গাড়ির হিসাব').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  db.cars.forEach(c=>{const t=c.entries.reduce((a,e)=>({sale:a.sale+num_(e.scheduled),paid:a.paid+num_(e.paid)}),{sale:0,paid:0});body.appendParagraph(c.name+' — '+c.owner).setHeading(DocumentApp.ParagraphHeading.HEADING2);body.appendTable([['মোট কিস্তি/বিক্রি','মোট আদায়','বাকি','ইনভেস্টমেন্ট','অন্যান্য খরচ'],[String(t.sale),String(t.paid),String(t.sale-t.paid),String(c.invest),String(c.expense)]]);});
  body.appendParagraph('ব্যবসায়িক বিনিয়োগ').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendTable([['তারিখ','ব্যবসা','টাকা','নোট'],...db.businessInvestments.map(x=>[x.date,x.name,String(x.amount),x.note])]);
  body.appendParagraph('অন্যান্য খরচ').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendTable([['তারিখ','খরচের নাম','টাকা','নোট'],...db.expenses.map(x=>[x.date,x.name,String(x.amount),x.note])]);
  doc.saveAndClose();
  const pdf=DriveApp.getFileById(doc.getId()).getAs(MimeType.PDF);
  const out=Utilities.base64Encode(pdf.getBytes());
  DriveApp.getFileById(doc.getId()).setTrashed(true);
  return {filename:(db.settings.association||'somiti')+'_full_report.pdf',base64:out};
}

function scheduledInstallments_(){
  const start=new Date(2025,0,1);
  const now=new Date();
  return Math.max(0,(now.getFullYear()-start.getFullYear())*12+(now.getMonth()-start.getMonth())+1);
}

function makeMemberStatementPdf(index){
  const db=getDB();
  const m=db.members[Number(index)];
  if(!m) throw new Error('সদস্য পাওয়া যায়নি');
  const monthly=2000;
  const totalInstallments=scheduledInstallments_();
  const paid=num_(m.paid);
  const paidInstallments=Math.floor(paid/monthly);
  const remainder=paid%monthly;
  const due=Math.max(totalInstallments*monthly-paid,0);
  const dueInstallments=Math.max(0,Math.ceil(due/monthly));
  const doc=DocumentApp.create((db.settings.association||'সমিতি')+' - '+m.name+' - সদস্য হিসাব');
  const body=doc.getBody();
  body.appendParagraph(db.settings.association||'সমিতি').setHeading(DocumentApp.ParagraphHeading.TITLE);
  body.appendParagraph('সদস্য কিস্তি হিসাব').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendParagraph('হিসাব শুরুর তারিখ: 01/01/2025 | মাসিক কিস্তি: ২,০০০ টাকা');
  body.appendTable([
    ['সদস্য ID',String(m.id||'')],
    ['সদস্যের নাম',String(m.name||'')],
    ['মোবাইল',String(m.mobile||'')],
    ['মোট নির্ধারিত কিস্তি',String(totalInstallments)],
    ['পরিশোধিত পূর্ণ কিস্তি',String(paidInstallments)],
    ['আংশিক জমা',String(remainder)],
    ['মোট জমা',String(paid)],
    ['বকেয়া কিস্তি',String(dueInstallments)],
    ['বকেয়া টাকা',String(due)]
  ]);
  const tx=db.txns.filter(t=>String(t.memberId)===String(m.id));
  body.appendParagraph('জমার বিবরণ').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  if(tx.length){
    body.appendTable([['তারিখ','মাস','জমা','নোট'],...tx.map(t=>[String(t.date||''),String(t.month||''),String(t.amount||0),String(t.note||'')])]);
  }else{
    body.appendParagraph('এখনও কোনো জমার লেনদেন রেকর্ড নেই।');
  }
  body.appendParagraph('প্রস্তুতের তারিখ: '+Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'dd/MM/yyyy HH:mm'));
  doc.saveAndClose();
  const pdf=DriveApp.getFileById(doc.getId()).getAs(MimeType.PDF);
  const out=Utilities.base64Encode(pdf.getBytes());
  DriveApp.getFileById(doc.getId()).setTrashed(true);
  return {filename:String(m.id||'member')+'_kisti_hisab.pdf',base64:out};
}

function makeReceiptPdf(type,index){
  const db=getDB();
  const doc=DocumentApp.create((db.settings.association||'সমিতি')+' - রসিদ');
  const body=doc.getBody();
  body.appendParagraph(db.settings.association||'সমিতি').setHeading(DocumentApp.ParagraphHeading.TITLE);
  body.appendParagraph('রসিদ');
  if(type==='txn'){const t=db.txns[index];const m=db.members.find(x=>x.id===t.memberId);body.appendTable([['সদস্য',m?m.name:''],['Member ID',t.memberId],['তারিখ',t.date],['মাস',t.month],['জমা',String(t.amount)],['নোট',t.note||'']]);}
  else {const ci=Number(index.split(':')[0]),ei=Number(index.split(':')[1]);const c=db.cars[ci],e=c.entries[ei];body.appendTable([['গাড়ি',c.name],['তারিখ',e.date],['মাস',e.month],['কিস্তি',String(e.scheduled)],['আদায়',String(e.paid)],['নোট',e.note||'']]);}
  doc.saveAndClose();
  const pdf=DriveApp.getFileById(doc.getId()).getAs(MimeType.PDF);
  const out=Utilities.base64Encode(pdf.getBytes());
  DriveApp.getFileById(doc.getId()).setTrashed(true);
  return {filename:'receipt_'+Date.now()+'.pdf',base64:out};
}


/**
 * One-time import.
 * The browser sends the original seed data; all names, amounts and car
 * schedules are stored in Google Sheet. The 34 deposit rows are mapped
 * I001..I034 to the 34 members in their original order so each deposit
 * shows the corresponding member name.
 */
function importOldData(oldData){
  if(!oldData||!oldData.members||!oldData.txns||!oldData.cars)
    throw new Error('পুরোনো ডাটা পাওয়া যায়নি।');
  saveDB(oldData);
  return {
    success:true,
    members:oldData.members.length,
    txns:oldData.txns.length,
    cars:oldData.cars.length,
    carEntries:oldData.cars.reduce((a,c)=>a+(c.entries||[]).length,0)
  };
}
