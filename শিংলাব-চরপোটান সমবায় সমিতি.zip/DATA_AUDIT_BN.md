# ডাটা যাচাই রিপোর্ট

## Final project seed data
- সদস্য: 34 জন
- সদস্যের মোট বিনিয়োগ: ৳ 16,32,000
- সদস্যের মোট জমা: ৳ 12,25,900
- সদস্যের মোট বকেয়া: ৳ 4,06,900
- জমা/Transactions: 34টি
- গাড়ি: 3টি
- কমিটি: 12 জন
- Admin PIN: 1234

## Excel reference check
`শিংলাব-চরপোটান_সমিতি_সাজানো_হিসাব.xlsx`-এর Members sheet-এর 34টি সদস্য record-এর ID, নাম, মোবাইল, ঠিকানা, যোগদানের তথ্য, বিনিয়োগ, জমা ও বকেয়া final project seed data-এর সঙ্গে মিলে গেছে।

## Existing warnings — ইচ্ছাকৃতভাবে পরিবর্তন করা হয়নি
Excel-এর `Data Check` sheet-এ আগে থেকেই কিছু সমস্যা লেখা আছে, যেমন:
- Installments EntryID-তে `I003` বারবার দেখা যাচ্ছে।
- Installments-এর তারিখে `01/01/205` দেখা যাচ্ছে।
- Auto-1/Auto-2/Auto-3-এর পরের কিছু row-তে কিস্তির amount/serial column নিয়ে অসামঞ্জস্য আছে।

এই ধরনের পুরোনো ডাটা silently বদলে দেওয়া হয়নি, কারণ এতে মূল হিসাব পরিবর্তিত হতে পারে। Final package-এ source data ও audit দুটোই রাখা হয়েছে।

## Google Sheet sync
Apps Script backend একই data model ধরে কাজ করে এবং `SHEET_ID` placeholder থাকলে প্রথম run-এ spreadsheet তৈরি করে Script Properties-এ ID সংরক্ষণ করতে পারে। Live Google Sheet-এর বর্তমান contents এই environment থেকে সরাসরি দেখা সম্ভব হয়নি; তাই live sheet-কে 100% verified বলা হচ্ছে না।
