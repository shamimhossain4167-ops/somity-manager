# APK বানানোর সহজ নিয়ম

1. এই project-এর সব ফাইল GitHub repository-তে আপলোড করুন।
2. `.github/workflows/build-apk.yml` ফাইলটি অবশ্যই থাকতে হবে।
3. GitHub-এর **Actions** → **Build and publish APK** খুলুন।
4. **Run workflow** → `main` → **Run workflow** চাপুন।
5. Build শেষ হলে একই workflow-এর **Artifacts**-এ `Shinglab-Somity-APK` পাবেন।
6. একই সঙ্গে **Releases**-এ `Shinglab Somity APK ...` নামে Release তৈরি হবে; সেখানে `app-debug.apk` সরাসরি ডাউনলোড করা যাবে।

> নতুন binary APK এই package-এর ভিতরে fake হিসেবে রাখা হয়নি। GitHub Actions-ই Android build করবে, যাতে APK প্রকৃত build environment-এ তৈরি হয়।
