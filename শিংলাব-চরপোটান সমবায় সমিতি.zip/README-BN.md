# শিংলাব-চরপোটান সমবায় সমিতি লিঃ — Final APK Project

এই ZIP-এ Android Studio/GitHub Actions দিয়ে Debug APK বানানোর জন্য সম্পূর্ণ project এবং Google Apps Script backend-এর final files আছে।

### GitHub Actions
1. GitHub-এ project upload করুন।
2. **Actions → Build APK → Run workflow** চাপুন।
3. কাজ শেষ হলে **Artifacts → Shinglab-Somity-APK** থেকে `app-debug.apk` নিন।

### Google Apps Script
`apps-script/Code.gs` এবং `apps-script/index.html` Google Apps Script project-এ রাখুন। Web app হিসেবে deploy করুন (Execute as: Me)। `MainActivity.java`-তে যে Web App URL আছে, সেটিই Android app-এর backend URL।

### Final dashboard update
- Home dashboard is redesigned to match the approved colorful reference: cash hero, 6 colorful financial/member cards, summary section, quick actions, and large bottom navigation.
- Association name is corrected everywhere to **শিংলাব-চরপোটান সমবায় সমিতি লিঃ**.
- Home page does not show member names or vehicle photos.
- Admin PIN protection and Google Apps Script sync are preserved.

### Verified data
34 সদস্য, 34 জমা/লেনদেন, 3 গাড়ি এবং 12 কমিটি সদস্যের seed data যাচাই করা হয়েছে।

### Important APK note
এই package-এ GitHub Actions workflow রাখা আছে যাতে GitHub থেকে Debug APK build করা যায়। এই environment-এ Android Gradle toolchain না থাকায় নতুন binary APK locally compile করা সম্ভব হয়নি; তাই ZIP-এর APK slot-এ কোনো fake/ভুল APK রাখা হয়নি।
